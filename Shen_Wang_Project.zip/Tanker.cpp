#include "Tanker.h"
Tanker::Tanker()
{
}
Tanker::Tanker(const std::string & name_, Point position_):Ship(name_,position_,100,100,10,2,0)
{
	cargo_capacity = 1000;
	cargo = 0;
	tankerstate = no_cargo_destination;
	cout << "Tanker " << name_ << " created.\n";
	loading_destination = nullptr;
	unloading_destination = nullptr;
}

Tanker::~Tanker()
{
	cout << "Tanker " << name << " destroyed.\n";
}

void Tanker::set_destination_position_and_speed(Point destination_point, double speed)
{
	if (tankerstate != no_cargo_destination) {
		throw invalid_argument(name + " has cargo destinations! ");
	}
	Ship::set_destination_position_and_speed(destination_point, speed);
}

void Tanker::set_destination_island_and_speed(Island * destination_island, double speed)
{
	if (tankerstate != no_cargo_destination) {
		throw invalid_argument(name + " has cargo destinations! ");
	}
	Ship::set_destination_island_and_speed(destination_island, speed);
}

void Tanker::set_course_and_speed(double course, double speed)
{
	if (tankerstate != no_cargo_destination) {
		throw invalid_argument(name + " has cargo destinations! ");
	}
	Ship::set_course_and_speed(course, speed);
}

void Tanker::set_load_destination(Island * load_island)
{
	if (tankerstate != no_cargo_destination) {
		throw invalid_argument(name + " has cargo destinations! ");
	}
	if (load_island == unloading_destination) {
		throw invalid_argument(name + " can not load on " + load_island->get_name() + " because it is the unloading destination!");
	}
	loading_destination = load_island;
	cout << name << " will load at " << load_island->get_name() << endl;
	if (unloading_destination != nullptr) {
		if(ship_state==docked){
			if (docked_Island = loading_destination) {
				tankerstate = loading;
			}
			else if (docked_Island = unloading_destination) {
				tankerstate = unloading;
			}
		}
		else if (!is_moving()) {
			if (cargo == 0 && can_dock(loading_destination)) {
				dock(loading_destination);
				tankerstate = loading;
			}
			else if (cargo > 0 && can_dock(unloading_destination)) {
				dock(unloading_destination);
				tankerstate = unloading;
			}
			else if (cargo == 0) {
				Ship::set_destination_island_and_speed(loading_destination, maxSpeed);
				tankerstate = moving_to_loading;
			}
			else if (cargo > 0) {
				Ship::set_destination_island_and_speed(unloading_destination, maxSpeed);
				tankerstate = moving_to_unloading;
			}
		}
	}
}

void Tanker::set_unload_destination(Island * unload_island)
{
	if (tankerstate != no_cargo_destination) {
		throw invalid_argument(name + " has cargo destinations! ");
	}	
	if (unload_island == loading_destination) {
		throw invalid_argument(name + " can not load on " + unload_island->get_name() + " because it is the loading destination!");
	}
	unloading_destination = unload_island;
	cout << name << " will unload at " << unload_island->get_name() << endl;
	if (loading_destination != nullptr) {//Start loading/unloading
		if (ship_state == docked) {
			if (docked_Island = loading_destination) {
				tankerstate = loading;
			}
			else if (docked_Island = unloading_destination) {
				tankerstate = unloading;
			}
		}
		else if (ship_state==stopped) {
			if (cargo == 0 && can_dock(loading_destination)) {
				dock(loading_destination);
				tankerstate = loading;
			}
			else if (cargo > 0 && can_dock(unloading_destination)) {
				dock(unloading_destination);
				tankerstate = unloading;
			}
			else if (cargo == 0) {
				Ship::set_destination_island_and_speed(loading_destination, maxSpeed);
				tankerstate = moving_to_loading;
			}
			else if (cargo > 0) {
				Ship::set_destination_island_and_speed(unloading_destination, maxSpeed);
				tankerstate = moving_to_unloading;
			}
		}
		else {
			throw invalid_argument(name + " cannot be commanded!");
		}
	}
}

void Tanker::stop()
{
	Ship::stop();
	tankerstate = no_cargo_destination;
	loading_destination = nullptr;
	unloading_destination = nullptr;
	cout << name << " now has no destination." << endl;
}

void Tanker::update()
{
	Ship::update();
	if (!can_move()) {
		tankerstate = no_cargo_destination;
		loading_destination = nullptr;
		unloading_destination = nullptr;
		cout << name << " now has no cargo destination." << endl;
		return;
	}
	if (tankerstate == moving_to_loading&&(!is_moving())) {
		dock(loading_destination);
			tankerstate = loading;
	}
	else if (tankerstate == moving_to_unloading && (!is_moving())) {
		dock(unloading_destination);
		tankerstate = unloading;
	}
	else if (tankerstate == loading) {
		Ship::refuel();
		if (cargo_capacity - cargo < 0.005) {
			cargo = cargo_capacity;
			Ship::set_destination_island_and_speed(unloading_destination, maxSpeed);
			tankerstate = moving_to_unloading;
		}
		else {
			cargo += docked_Island->provide_fuel(cargo_capacity - cargo);
			cout << name << " now has " << cargo << " tons of cargo." << endl;
		}
	}
	else if (tankerstate == unloading) {
		Ship::refuel();
		if (cargo ==0.0) {
			Ship::set_destination_island_and_speed(loading_destination, maxSpeed);
			tankerstate = moving_to_loading;
		}
		else {
			docked_Island->accept_fuel(cargo);
			cargo = 0.0;
		}
	}
}

void Tanker::describe() const
{
	cout << "Tanker\t";
	Ship::describe();
	cout << " ,containing " << cargo << " tons of cargo ";
	switch (tankerstate) {
	case no_cargo_destination:cout << "has no cargo destination." << endl; break;
	case moving_to_loading:cout << " is moving to loading destination." << endl; break;
	case loading:cout << " is loading." << endl; break;
	case moving_to_unloading:cout << "is moving to unloading destination." << endl; break;
	case unloading:cout << " is unloading." << endl; break;
	}
}
