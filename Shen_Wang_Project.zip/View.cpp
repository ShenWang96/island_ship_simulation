#include "View.h"


/* *** Use this function to calculate the subscripts for the cell. */

/* *** This code assumes the specified private member variables. */


// Calculate the cell subscripts corresponding to the supplied location parameter, 
// using the current size, scale, and origin of the display. 
// This function assumes that origin is a  member variable of type Point, 
// scale is a double value, and size is an integer for the number of rows/columns 
// currently being used for the grid.
// Return true if the location is within the grid, false if not
bool View::get_subscripts(int &ix, int &iy, sim* s)
{
	// adjust with origin and scale
	Cartesian_vector subscripts = (s->location - origin) / scale;	//Overload "-"
	// truncate coordinates to appropriate integer after taking the floor
	// floor function will produce the greatest integer that is 
	// smaller than the argument, even for negative values. 
	// So - 0.05 is floored to -1., which will be outside the array.
	ix = int(floor(subscripts.delta_x));
	iy = int(floor(subscripts.delta_y));
	// if out of range, return false
	if ((ix < 0) || (ix >= size) || (iy < 0) || (iy >= size)) {
		return false;
	}
	else {
		return true;
	}
}

View::View()
{
	cout << "View constructed" << endl;
}

View::~View()
{
	cout << "View destructed" << endl;
}

void View::update_location(const std::string & name, Point location)
{
	if (sims.empty()) {
		sim* temp = new sim();
		temp->name = name; temp->location = location;
		sims.push_back(temp);
	}
	for (size_t i = 0; i < sims.size(); i++) {
		if (sims[i]->name == name) {
			sims[i]->location = location;
			return;
		}
	}
	sim* temp = new sim();
	temp->name = name; temp->location = location;
	sims.push_back(temp);
	//redraw the map
	draw();
}

void View::update_remove(const std::string & name)
{
	for (size_t i = 0; i < sims.size(); i++) {
		if (sims[i]->name == name) {
			sims.erase(sims.begin() + i);
			return;
		}
	}
	//redraw the map
	draw();
}

void View::draw()
{
	//system("CLS");
	//initialize and set points to coordinates
	unshowns.clear();
	initialize();
	int ix, iy;
	cout << endl;
	for (size_t i = 0; i < sims.size(); i++) {
		if (get_subscripts(ix, iy, sims[i])) {
			if (Cells[iy][ix][0] == '.') {
				Cells[iy][ix][0] = toupper(sims[i]->name[0]);
				Cells[iy][ix][1] = toupper(sims[i]->name[1]);
			}
			else {
				Cells[iy][ix][0] = '*';
				Cells[iy][ix][1] = ' ';
			}
		}
		else {
			unshowns.push_back(sims[i]->name);
		}
	}
	//draw 
	for (int i = (size-1); i >= 0; i--) {
		for (size_t j = 0; j < size; j++) {
			cout << Cells[i][j][0] << Cells[i][j][1];
		}
		cout << endl;
	}
	//Declare all objects that is out of range
	if (unshowns.size() > 0) {
		cout << "OBJECTS OUT OUTSIDE MAP: ";
		for (size_t i = 0; i < unshowns.size(); i++) {
			cout << unshowns[i] << "\t";
		}
	}
}

void View::set_size(int size_)
{
	if (size_ > 30) {
		throw invalid_argument("Map is too large!");

	}
	else if (size_ <= 6) {
		throw invalid_argument("Map is too small!");
	}
	else {
		size = size_;
		cout << "map size set to " << size;
	}
	//redraw the map
	draw();
}

void View::set_scale(double scale_)
{
	scale = scale_;
	cout << "map scale set to " << scale;
	//redraw the map
	draw();
}

void View::set_origin(Point origin_)
{
	origin = origin_;
	cout << " map origin set to " << origin;
	//redraw the map
	draw();
}

void View::set_defaults()
{
	size = 25;
	scale = 2;
	origin = Point(-10, -10);
	cout << "set to default setting" << endl;
	draw();
}
void View::initialize() {
	for (int i = 0; i < 30; i++) {
		for (int j = 0; j < 30; j++) {
			Cells[i][j][0] = '.';
			Cells[i][j][1] = ' ';
		}
	}
}
