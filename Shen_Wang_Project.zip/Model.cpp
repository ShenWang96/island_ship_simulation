#include "Model.h"



Model::Model()
{
	/* create some islands and ships using the following code in the Model constructor.
	Do not change the execution order of these code fragments. You should delete this comment. */
	Island *island_exxon = new Island("Exxon", Point(10, 10), 1000, 200);
	Island *island_shell = new Island("Shell", Point(0, 30), 1000, 200);
	Island *island_bermuda = new Island("Bermuda", Point(20, 20));
	Islands.push_back(island_exxon); Sims.push_back(island_exxon);
	Islands.push_back(island_shell); Sims.push_back(island_shell);
	Islands.push_back(island_bermuda); Sims.push_back(island_bermuda);
	Ships.push_back(create_ship("Ajax", "Cruiser", Point(15, 15))); Sims.push_back(Ships[0]);
	Ships.push_back(create_ship("Xerxes", "Cruiser", Point(25, 25))); Sims.push_back(Ships[1]);
	Ships.push_back(create_ship("Valdez", "Tanker", Point(30, 30))); Sims.push_back(Ships[2]);
	
	time = 0;
	cout << "Model constructed" << endl;
}

Model::~Model()
{
	while (Sims.size() > 0) {
		Sims[Sims.size() - 1]->~Sim_object();
		Sims.pop_back();
	}
	while (Views.size() > 0) {
		Views[Views.size() - 1]->~View();
		Views.pop_back();
	}
	cout << "Model destructed" << endl;
}

bool Model::is_name_in_use(const std::string & name) const
{
	string n = (name.substr(0, 2));
	for (size_t i = 0; i < Sims.size();i++) {
		string in = (Sims[i]->get_name()).substr(0, 2);
		if (n == in) {
			return true;
		}
	}
	return false;
}

bool Model::is_island_present(const std::string & name) const
{

	for (size_t i = 0; i < Islands.size(); i++) {
		if (name == Islands[i]->get_name()) {
			return true;
		}
	}
	return false;
}

Island * Model::get_island_ptr(const std::string & name) const
{
	for (size_t i = 0; i < Islands.size(); i++) {
		if (name == Islands[i]->get_name()) {
			return Islands[i];
		}
	}
	return nullptr;
}

bool Model::is_ship_present(const std::string & name) const
{
	for (size_t i = 0; i < Ships.size(); i++) {
		if (name.substr(0, 2) == Ships[i]->get_name().substr(0,2)) {
			return true;
		}
	}
	return false;
}

void Model::add_ship(Ship * s)
{	//Add the ship pointer to the list first.
	Ships.push_back(s);
	Sims.push_back(s);
	//Update the view
	notify_location(s->get_name(), s->get_location());
}

Ship * Model::get_ship_ptr(const std::string & name) const
{
	for (size_t i = 0; i < Ships.size(); i++) {
		if (name == Ships[i]->get_name()) {
			return Ships[i];
		}
	}
	return nullptr;
}

void Model::describe() const
{
	g_Model_ptr->sortSims();
	for (size_t i = 0; i < Sims.size(); i++) {
		Sims[i]->describe();
	}
}

void Model::update()
{
	time++;
	
	for (size_t i = 0; i < Sims.size(); i++) {
		Sims[i]->update(); cout << " || ";
	}


	//Check sunk ships
	for (size_t i = 0; i < Ships.size(); i++) {
		if (Ships[i]->is_on_the_bottom()) {
			removeSim(Ships[i]->get_name());
			Ships.erase(Ships.begin() + i);
		}
	}
	//Update the view
	Views[0]->draw();
}

void Model::attach(View * v)
{
	Views.push_back(v);
	for (size_t i = 0; i < Sims.size(); i++) {
		notify_location(Sims[i]->get_name(), Sims[i]->get_location());
	}
}

void Model::detach(View *)
{
	Views.pop_back();
	return;
}

void Model::notify_location(const std::string & name, Point location)
{
	Views[0]->update_location(name, location);
}

void Model::notify_gone(const std::string & name)
{
	Views[0]->update_remove(name);
}

void Model::removeSim(string n) {
	for (size_t i = 0; i < Sims.size(); i++) {
		if (Sims[i]->get_name()== n) {
			Sims.erase(Sims.begin() + i);
			return;
		}
	}
}
void Model::sortSims() {
	for (size_t i = Sims.size() - 1; i >1; i--) {
		for (size_t j = 0; j < i; j++) {
			int n1 = tolower((Sims[j]->get_name())[0]);
			int n2 = tolower((Sims[j + 1]->get_name())[0]);
			if (n1 > n2) {
				Sim_object* temp = Sims[j];
				Sims[j] = Sims[j + 1];
				Sims[j + 1] = temp;
			}
		}
	}

}
void Model::sortShips() {//Buble sort
	for (size_t i = Ships.size()-1; i >1; i--) {
		for (size_t j = 0; j < i; j++) {
			int n1 = tolower((Ships[j]->get_name())[0]);
			int n2 = tolower((Ships[j+1]->get_name())[0]);
			if (n1 > n2) {
				Ship* temp = Ships[j];
				Ships[j] = Ships[j + 1];
				Ships[j + 1] = temp;
			}
		}
	}
}

void Model::sortIslands() {
	for (size_t i = Islands.size() - 1; i >1; i--) {
		for (size_t j = 0; j < i; j++) {
			int n1 = tolower((Islands[j]->get_name())[0]);
			int n2 = tolower((Islands[j + 1]->get_name())[0]);
			if (n1 > n2) {
				Island* temp = Islands[j];
				Islands[j] = Islands[j + 1];
				Islands[j + 1] = temp;
			}
		}
	}

}