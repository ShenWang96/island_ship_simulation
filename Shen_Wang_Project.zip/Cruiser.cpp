#include "Cruiser.h"

Cruiser::Cruiser(const std::string & name_, Point position_) :Ship(name_, position_, 1000, 1000, 20, 10, 6)
{
	firepower = 3;
	attacking_range = 15.0;
	target = nullptr;
	cruiserstate = not_attacking;
	cout << "Cruiser " << name << " created." << endl;
}

Cruiser::~Cruiser()
{
	cout << "Cruiser " << name << " has been destroyed." << endl;
}

void Cruiser::update()
{
	Ship::update();
	if(cruiserstate==attacking){
		if (!is_afloat()||!(target->is_afloat())) {
			stop_attack();
			return;
		}
		cout << name << " is attacking " << target->get_name();
		if (Compass_position(get_location(), target->get_location()).range<attacking_range) {
			cout << name << " fires ";
			target->receive_hit(firepower, this);
		}
		else {
			cout << "target out of range.";
			stop_attack();
		}
	}
}

void Cruiser::describe() const
{
	cout << "Cruiser ";
	Ship::describe();
	if (cruiserstate == attacking) {
		cout << " is attacking " << target->get_name();
	}
}

//void Cruiser::receive_hit(int hit_force, Ship * attacker_ptr)
//{
//}

void Cruiser::attack(Ship * target_ptr_)
{
	if (!is_afloat()) {
		throw invalid_argument(name + " cannot attack!");
	}
	if (this == target_ptr_) {
		throw invalid_argument(name + " cannot attack itself!");
	}
	if (target == target_ptr_) {
		throw invalid_argument(name + " is already attacking the target!");
	}

	target = target_ptr_;
	cruiserstate = attacking;
	cout << name << " will attack " << target_ptr_->get_name() << endl;
}

void Cruiser::stop_attack()
{
	if (cruiserstate == not_attacking) {
		throw invalid_argument(name + " was not attacking!");
	}
	cout << name << " stopped attacking" << endl;
	target = nullptr;
	cruiserstate = not_attacking;
}
