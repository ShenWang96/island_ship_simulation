#ifndef CONTROLLER_H
#define CONTROLLER_H

#include"View.h"
#include"Model.h"
#include<string>
#include<iostream>

class Controller {
public:
	// output constructor message
	Controller();
	// output destructor message
	~Controller();

	// create View object, run the program by acccepting user commands, then destroy View object
	void run();
	void instruction();
private:
	// Controller keeps its own pointer to the View because it has to manage the View.
	// Future versions will need to manage more than one view.
	View* view_ptr;
	string command;
	vector<string>prompts;
	//Model* g_Model_ptr;
};

#endif