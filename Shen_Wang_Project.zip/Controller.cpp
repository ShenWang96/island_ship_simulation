#include "Controller.h"

Controller::Controller()
{
	cout << "Controller constructed" << endl;
}

Controller::~Controller()
{
	cout << "Controller destructed" << endl;
}
void Controller::instruction() {
	cout << "Please type one of the following commands (and parameters seperated with space):\n";
	cout << "View Commands:\n1.default\n2.size (size)\n3.zoom (scale)\n4.pan (x) (y)\n5.show\n";
	cout << "Model Commands:\n6.status\n7.go\n8.create (ShipName) (Tanker/Cruiser) (x) (y)\n";
	cout << "Ship Commands:\n9.(ShipName) course (compass heading) (speed)\n10.(ShipName) position (x) (y) (speed)\n11.(ShipName) destination (IslandName) (speed)\n12.(ShipName) load_at (IslandName)\n13.(ShipName) unload_at (IslandName)\n";
	cout << "14.(ShipName) dock_at (IslandName)\n15.(ShipName) attack (TargetName)\n16.(ShipName) refuel\n17.(ShipName) stop\n18.(ShipName) stop_attack";
}
void Controller::run()
{
	view_ptr = new View();
	g_Model_ptr->attach(view_ptr);
	//clear old prompts
	while (true) {
		vector<string>().swap(prompts);
		cout << "\nThe time now is " << g_Model_ptr->get_time() << "\nEnter a command(\"instruction\" to see list of commands,\"quit\" to terminate program):" << endl;
		getline(cin, command);


		//split command first
		int k = 0;
		for (size_t i = 0; i < command.size(); i++) {
			if (command[i] == ' ') {
				prompts.push_back(command.substr(k, i - k));
				k = i + 1;
			}
		}
		prompts.push_back(command.substr(k, command.size() - k));

		//try to  identify the command and run it


		try {
			if (prompts[0].size() < 2 || prompts[0].size() > 15) {
				throw invalid_argument("invalid command!");
			}
			if (prompts.size() > 1) {
				if (g_Model_ptr->is_ship_present(prompts[0])) {//If a existing ship name
					Ship* tempShip = g_Model_ptr->get_ship_ptr(prompts[0]);
					string shipCommand = prompts[1];
					if (shipCommand == "course") {
						if (prompts.size() < 4) {
							throw invalid_argument("invalide parameter for set a course !");
						}
						double heading = stod(prompts[2]), speed = stod(prompts[3]);
						if (heading >= 0.0 && heading<360 && speed>0.0) {
							tempShip->set_course_and_speed(heading, speed);
						}
						else {
							throw invalid_argument("invalide parameter for set a course !");
						}
					}
					else if (shipCommand == "position") {
						if (prompts.size() < 5) {
							throw invalid_argument("invalide parameter for going to a position !");
						}
						double xPos = stod(prompts[2]), yPos = stod(prompts[3]), speed = stod(prompts[4]);
						if (speed < 0) {
							throw invalid_argument("invalide speed entered!");
						}
						tempShip->set_destination_position_and_speed(Point(xPos, yPos), speed);
					}
					else if (shipCommand == "destination") {
						if (prompts.size() < 4 || !(g_Model_ptr->is_island_present(prompts[2])) || stod(prompts[3]) < 0) {
							throw invalid_argument("invalide parameter for going to an island!");
						}
						tempShip->set_destination_island_and_speed(g_Model_ptr->get_island_ptr(prompts[2]), stod(prompts[3]));
					}
					else if (shipCommand == "load_at") {
						if (g_Model_ptr->is_island_present(prompts[2])) {
							tempShip->set_load_destination(g_Model_ptr->get_island_ptr(prompts[2]));
						}
						else {
							throw invalid_argument("Island not exist!");
						}
					}
					else if (shipCommand == "unload_at") {
						if (g_Model_ptr->is_island_present(prompts[2])) {
							tempShip->set_unload_destination(g_Model_ptr->get_island_ptr(prompts[2]));
						}
						else {
							throw invalid_argument("Island not exist!");
						}
					}
					else if (shipCommand == "dock_at") {
						if (g_Model_ptr->is_island_present(prompts[2])) {
							tempShip->dock(g_Model_ptr->get_island_ptr(prompts[2]));
						}
						else {
							throw invalid_argument("Island not exist!");
						}
					}
					else if (shipCommand == "attack")
					{
						if (g_Model_ptr->is_ship_present(prompts[2])) {
							tempShip->attack(g_Model_ptr->get_ship_ptr(prompts[2]));
						}
						else {
							throw invalid_argument("Target not exist!");
						}
					}
					else if (shipCommand == "refuel") {
						tempShip->refuel();
					}
					else if (shipCommand == "stop") {
						tempShip->stop();
					}
					else if (shipCommand == "stop_attack") {
						tempShip->stop_attack();
					}


					else {
						throw invalid_argument(" the command is invalid!");
					}
				}

				//If not a ship command, briefly distinguish the command by the number of parameters:
				else if (prompts.size() > 2) {
					if (prompts[0] == "create") {
						if (prompts.size() < 5) {
							throw invalid_argument("invalid parameter for creating a ship!");
						}
						string name = prompts[1];
						if (g_Model_ptr->is_ship_present(name)) {
							throw invalid_argument("ship name is already used!");
						}
						string shipType = prompts[2];
						double shipX = stod(prompts[3]);
						double shipY = stod(prompts[4]);
						g_Model_ptr->add_ship(create_ship(name, shipType, Point(shipX, shipY)));
					}
					else if (prompts[0] == "pan") {
						if (prompts.size() == 3)
							view_ptr->set_origin(Point(stod(prompts[1]), stod(prompts[2])));
						else {
							throw invalid_argument(" the command is invalid!");
						}
					}


					else {
						throw invalid_argument(" the command is invalid!");
					}
				}

				else {
					if (prompts[0] == "size") {
						view_ptr->set_size(stoi(prompts[1]));
					}
					else if (prompts[0] == "zoom") {
						view_ptr->set_scale(stod(prompts[1]));
					}

					else {
						throw invalid_argument(" the command is invalid!");
					}
				}
			}
			//if single-word command
			else
			{
				if (prompts[0] == "quit") {
					g_Model_ptr->~Model();
					cout << "Done";
					return;
				}
				else if (prompts[0] == "instruction") {
					instruction();
				}
				else if (prompts[0] == "status") {
					g_Model_ptr->describe();
				}
				else if (prompts[0] == "go") {
					g_Model_ptr->update();
				}
				else if (prompts[0] == "default") {
					view_ptr->set_defaults();
				}
				else if (prompts[0] == "show") {
					g_Model_ptr->update();
					view_ptr->draw();
				}

				else {
					throw invalid_argument(" the command is invalid!");
				}
			}

		}
		catch (const invalid_argument& e) {
			cout << e.what();
		}

	}
}
