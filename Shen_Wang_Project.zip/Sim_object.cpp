#include "Sim_object.h"

Sim_object::Sim_object()
{
	cout << "Sim_object " << get_name() << " constructed" << endl;
}

Sim_object::Sim_object(const std::string & name_)
{
	name = name_;
}

Sim_object::~Sim_object()
{
	cout << "Sim_object " << get_name() << " destructed" << endl;
}
