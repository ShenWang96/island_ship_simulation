#pragma once
class Cartesian_vector {

};