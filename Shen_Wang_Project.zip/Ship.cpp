#include "Ship.h"
#include"Model.h"

/*
Define the destructor function even if it was declared as a pure virtual function.
This seems odd, because pure virtual functions are usually not defined in the class
that declares them. But this is often done as a way to make a class abstract, 
if there is no other virtual function that makes sense to mark as pure. Here we
are defining it just to get the destructor message output.
*/

Ship::Ship()
{
}

Ship::Ship(const std::string & name_, Point position_, double fuel_capacity_, double fuel_,double maximum_speed_, double fuel_consumption_, int resistance_) 
{
	if (name_.size() < 2 || name_.size() > 15) {
		throw invalid_argument("Not a valid ship name!");
	}
	name= name_;
	fuel = fuel_;
	fuel_capacity = fuel_capacity_;
	maxSpeed = maximum_speed_;
	fuel_consumption = fuel_consumption_;
	resistance = resistance_;
	ship_state = stopped;
	track = Track_base(position_, Course_speed(0, 0));
	cout << "Ship " << get_name() << " constructed" << endl;
}

Ship::~Ship()
{
	cout << "Ship "  << get_name() << " destructed" << endl;
}

bool Ship::can_move() const
{
	if((!is_afloat())||ship_state==dead_in_the_water){
	return false;
	}
	return true;
}

bool Ship::is_moving() const
{
	if(ship_state==moving_on_course||ship_state==moving_to_island||ship_state==moving_to_position){
		return true;
	}
	return false;
}

bool Ship::is_docked() const
{

	return ship_state==docked;
}

bool Ship::is_afloat() const
{	if(ship_state==sinking||ship_state==sunk||ship_state==on_the_bottom){
	return false;
}
return true;
}

bool Ship::is_on_the_bottom() const
{
	return ship_state==on_the_bottom;
}

bool Ship::can_dock(Island * island_ptr) const
{
	if (ship_state == stopped && cartesian_distance(track.get_position(), island_ptr->get_location()) < 0.1) {
		return true;
	}
	return false;
}

void Ship::update()
{
	cout << name;
	if (is_afloat()) {
		if (resistance < 0) {
			track.set_speed(0);
			ship_state = sinking;
			cout << " is sinking" << endl;
			return;
		}
		
	}
	if (is_afloat()) {
		if (is_moving()) {
			calculate_movement();

			g_Model_ptr->notify_location(name, track.get_position());
			cout << " is now at " << track.get_position();
		}
		else if (ship_state == stopped) {
			cout << " stopped at " << track.get_position();
		}
		else if (is_docked()) {
			cout << " docked at " << docked_Island->get_name();
		}
		else if(ship_state==dead_in_the_water){
			cout << " is dead in the water at " << track.get_position();
		}
	}
	else {
		switch (ship_state) {
		case sinking:ship_state = sunk; cout << " is sunk" << endl; g_Model_ptr->notify_gone(name); break;
		case sunk:ship_state = on_the_bottom; cout << " is on the bottom" << endl; break;
		case on_the_bottom:cout << " is on the bottom" << endl; break;
		}
	}
}

void Ship::describe() const
{
	cout << name << "\t" << track.get_position();
	switch (ship_state)
	{
	case sinking:cout << " is sinking" << endl; return;
	case sunk:cout << " is sunk" << endl; return;
	case on_the_bottom:cout << " is on the bottom" << endl; return;
	default:
		break;
	}
	cout << " with " << fuel << " tons of fuels" << " and resistance of " << resistance;
	switch (ship_state)
	{
	case moving_to_position:cout << " moving to " << destination_point; break;
	case moving_to_island:cout << " moving to " << destination_Island->get_name(); break;
	case moving_on_course:cout << "moving on course..."; break;
	case docked:cout << " docked at " << docked_Island->get_name(); break;
	case stopped:cout << " stopped."; break;
	case dead_in_the_water:cout << " dead in the water."; break;
	default:
		break;
	}
}

void Ship::broadcast_current_state() const
{
	g_Model_ptr->notify_location(name, track.get_position());
}

void Ship::set_destination_position_and_speed(Point destination_position, double speed)
{
	if (!can_move()) {
		throw invalid_argument(name + " cannot move!");
	}
	else if (speed > maxSpeed) {
		throw invalid_argument(name + " cannot move with specified speed!");
	}
	else {
		ship_state = moving_to_position;
		cout << name << " will move to " << destination_position;
		destination_Island = nullptr;
		destination_point = destination_position;
		track=Track_base(track.get_position(),Course_speed(Compass_vector(track.get_position(), destination_position).direction,speed));
	}
}

void Ship::set_destination_island_and_speed(Island * destination_island, double speed)
{
	if (!can_move()) {
		throw invalid_argument(name + " cannot move!");
	}
	else if (speed > maxSpeed) {
		throw invalid_argument(name + " cannot move with specified speed!");
	}
	else {
		destination_Island = destination_island;
		destination_point = destination_island->get_location();
		ship_state = moving_to_island;
		track = Track_base(track.get_position(), Course_speed(Compass_vector(track.get_position(), destination_island->get_location()).direction, speed));
		cout << name << " is moving to " << destination_island->get_name() << endl;
	}
}

void Ship::set_course_and_speed(double course, double speed)
{
	if (!can_move()) {
		throw invalid_argument(name + " cannot move!");
	}
	else if (speed > maxSpeed) {
		throw invalid_argument(name + " cannot move with specified speed!");
	}
	else {
		destination_Island = nullptr;
		//Set the direction as course and distance infinity
		ship_state = moving_on_course;
		destination_point = track.get_position() + Compass_vector(Polar_vector(10000, course));
		track = Track_base(track.get_position(), Course_speed(course, speed), speed);
		cout << name << " is moving on " << course<<endl;
	}
}

void Ship::stop()
{
	if (!is_afloat() || ship_state == dead_in_the_water) {
		throw invalid_argument(name + " cannot be controlled");
	}
	ship_state = stopped;
	track = Track_base(track.get_position(),Course_speed(0,0));
}

void Ship::dock(Island * island_ptr)
{
	if (ship_state != stopped || !can_dock(island_ptr)) {
		throw invalid_argument(name + " cannot dock on " + island_ptr->get_name())	;
	}
	track = Track_base(track.get_position(), Course_speed(0, 0));
	docked_Island = island_ptr;
	ship_state = docked;
	cout << name << " docks at " << island_ptr->get_name()<<endl;

}

void Ship::refuel()
{
	if (ship_state != docked) {
		throw invalid_argument(name + " is not docked!" );
	}
	double fuelneeded = fuel_capacity - fuel;
	if (fuelneeded <= 0.005) {
		fuel = fuel_capacity;
	}
	else {
		fuel += docked_Island->provide_fuel(fuelneeded);
	}
	cout << name << " now has " << fuel << " tons of fuels" << endl;
}

void Ship::set_load_destination(Island *)
{
	throw invalid_argument(name + " cannot load at destination!");
}

void Ship::set_unload_destination(Island *)
{
	throw invalid_argument(name + " cannot unload at destination!");
}

void Ship::attack(Ship * in_target_ptr)
{
	throw invalid_argument(name + " cannot load attack!");
}

void Ship::stop_attack()
{
	throw invalid_argument(name + " cannot stop attack!");
}

void Ship::receive_hit(int hit_force, Ship * attacker_ptr)
{
	resistance -= hit_force;
	cout << name << " hit with " << resistance << " resistance left ";
}

double Ship::get_maximum_speed() const
{
	return maxSpeed;
}

double Ship::get_speed() {
	return track.get_speed();
}

Island * Ship::get_docked_Island() const
{
	return docked_Island;
}

Island * Ship::get_destination_Island() const
{
	return destination_Island;
}

/* Private Function Definitions */

/*
Calculate the new position of a ship based on how it is moving, its speed, and
fuel state. This function should be called only if the state is 
moving_to_position, moving_to_island, or moving_on_course.

Track_base has an update_position(double time) function that computes the new position
of an object after the specified time has elapsed. If the Ship is going to move
for a full time unit (one hour), then it will get go the "full step" distance,
so update_position would be called with time = 1.0. If we can move less than that,
e.g. due to not enough fuel, update position  will be called with the corresponding
time less than 1.0.

For clarity in specifying the computation, this code assumes the specified private variable names, 
but you may change the variable names or enum class names, or state names if you wish (e.g. movement_state).
*/
void Ship:: calculate_movement()
{
	// Compute values for how much we need to move, and how much we can, and how long we can,
	// given the fuel state, then decide what to do.
	double time = 1.0;	// "full step" time
	// get the distance to destination
	double destination_distance = cartesian_distance(get_location(), destination_point);
	// get full step distance we can move on this time step
	double full_distance = get_speed() * time;
	// get fuel required for full step distance
	double full_fuel_required = full_distance * fuel_consumption;	// tons = nm * tons/nm
	// how far and how long can we sail in this time period based on the fuel state?
	double distance_possible, time_possible;
	if(full_fuel_required <= fuel) {
		distance_possible = full_distance;
		time_possible = time;
		}
	else {
		distance_possible = fuel / fuel_consumption;	// nm = tons / tons/nm
		time_possible = (distance_possible / full_distance) * time;
		}
	
	// are we are moving to a destination, and is the destination within the distance possible?
	if((ship_state == State::moving_to_position || ship_state== State::moving_to_island) && destination_distance <= distance_possible) {
		// yes, make our new position the destination
		track.set_position(destination_point);
		// we travel the destination distance, using that much fuel
		double fuel_required = destination_distance * fuel_consumption;
		fuel -= fuel_required;
		track.set_speed(0.);
		ship_state = State::stopped;
		}
	else {
		// go as far as we can, stay in the same movement state
		// simply move for the amount of time possible
		track.update_position(time_possible);
		// have we used up our fuel?
		if(full_fuel_required >= fuel) {
			fuel = 0.0;
			track.set_speed(0.);
			ship_state = State::dead_in_the_water;
			}
		else {
			fuel -= full_fuel_required;
			}
		}
}

