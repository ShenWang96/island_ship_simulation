#include "Island.h"
#include "Model.h"
Island::Island(const std::string & name_, Point position_, double fuel_, double production_rate_) :position(position_) {
	if (name_.size() < 2 || name_.size() > 15) {
		throw invalid_argument("creating island " + name_ + " failed, name is invalid.");
	}
	name = name_;
	fuel = fuel_;
	productionRate = production_rate_;
	cout << "Island " << get_name() << " constructed" << endl;
};

Island::~Island()
{
	cout << "Island " << get_name() << " destructed" << endl;
}

void Island::update()
{
	if (productionRate > 0) {
		fuel += productionRate;
		cout << name << " fuel storage increased to " << fuel;
	}
}

void Island::describe() const
{
	cout << name << " contains " << fuel << " tons of fuels with production rate of " << productionRate << endl;
}

void Island::broadcast_current_state() const
{
	g_Model_ptr->notify_location(name, position);
	
}

double Island::provide_fuel(double request)
{
	if (fuel == 0) {
		cout << name << " cannot provide any fuels" << endl;
		return 0;
	}
	else if (fuel <= request) {
		double output = fuel;
		fuel = 0;
		cout << name << " provided " << fuel << " fuels, the current storage is 0.0" << endl;
		return output;
	}
	else {
		fuel -= request;
		cout << name << " provided " << request << " fuels, the current storage is " << fuel << endl;
		return request;
	}
}

void Island::accept_fuel(double amount)
{	
	fuel += amount;
	std::cout << name << " received " << amount << " fuels, the current fuel storage is " << fuel << endl;
}
